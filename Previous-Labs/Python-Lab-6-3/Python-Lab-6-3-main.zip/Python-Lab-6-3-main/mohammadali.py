n = int(input())
def majzor(n):
    return n**2
print(majzor(n))
