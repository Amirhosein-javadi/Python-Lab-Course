# Python-Lab-6

Team Members
- Mohammad Amin Haji Khodaverdian
- Mohammad Ali Ahmadi Zareh
- Hamed Rastaghi
- Amirhosein Javadi
